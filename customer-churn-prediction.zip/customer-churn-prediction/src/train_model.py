"""
train_model.py
---------------
COMPLETE, RUNNABLE Customer Churn Prediction project.

Run from the project root with:
    python src/train_model.py

This single script performs every step required for the academic project:
    1. Load dataset
    2. Explore dataset
    3. Clean & preprocess data (missing values, duplicates, dtype fixes)
    4. Encode categorical features
    5. Train/test split (stratified, since churn is imbalanced)
    6. Train THREE models: Logistic Regression, Random Forest, XGBoost
    7. Evaluate each with Accuracy, Precision, Recall, F1, ROC-AUC, Confusion Matrix
    8. Visualizations (saved to outputs/)
    9. Feature importance / churn factor analysis
    10. Compare all three models and pick the best
    11. Save predictions.csv

All plots are saved into outputs/ so they can be embedded in a report or
presentation. Every print() statement is labelled so the console output
reads like a lab report.
"""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix, classification_report
)

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

# ------------------------------------------------------------------
# Global settings
# ------------------------------------------------------------------
sns.set_style("whitegrid")
plt.rcParams.update({
    "font.size": 12,
    "axes.titlesize": 15,
    "axes.titleweight": "bold",
    "axes.labelsize": 12,
})

DATA_PATH = "data/customer_churn.csv"
OUTPUT_DIR = "outputs"
RANDOM_STATE = 42


def section(title):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


# ==================================================================
# 1. LOAD DATASET
# ==================================================================
section("1. LOAD DATASET")
df = pd.read_csv(DATA_PATH)
print(f"Dataset loaded successfully from '{DATA_PATH}'")


# ==================================================================
# 2. DATASET OVERVIEW
# ==================================================================
section("2. DATASET OVERVIEW")

print(f"\nShape of dataset (rows, columns): {df.shape}")

print("\nFirst 5 rows:")
print(df.head())

print("\nColumn names:")
print(list(df.columns))

print("\nData types:")
print(df.dtypes)

print("\nMissing values per column (before cleaning):")
print(df.isnull().sum())

print(f"\nChurn class balance:\n{df['Churn'].value_counts()}")
print(f"\nChurn rate: {(df['Churn'] == 'Yes').mean() * 100:.1f}%")


# ==================================================================
# 3. DATA CLEANING
# ==================================================================
section("3. DATA CLEANING")

# --- 3.1 Drop identifier column (not a predictive feature) ---
if "customerID" in df.columns:
    df = df.drop(columns=["customerID"])
    print("Dropped 'customerID' - it is a unique identifier, not a predictive feature.")

# --- 3.2 Remove duplicate rows ---
n_dupes = df.duplicated().sum()
print(f"Duplicate rows found: {n_dupes}")
df = df.drop_duplicates().reset_index(drop=True)
print(f"Shape after removing duplicates: {df.shape}")

# --- 3.3 Fix TotalCharges (a known real-world quirk: blank strings for
#         customers with 0 tenure, stored as object dtype instead of numeric)
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
print(f"\nConverted 'TotalCharges' to numeric. "
      f"New missing values created by coercion: {df['TotalCharges'].isnull().sum()}")

# --- 3.4 Identify numerical vs categorical columns ---
target_col = "Churn"
numerical_cols = [c for c in df.columns
                   if pd.api.types.is_numeric_dtype(df[c]) and c != target_col]
categorical_cols = [c for c in df.columns
                     if not pd.api.types.is_numeric_dtype(df[c]) and c != target_col]

print(f"\nNumerical feature columns: {numerical_cols}")
print(f"Categorical feature columns: {categorical_cols}")
print(f"Target column: {target_col}")

# --- 3.5 Handle missing numerical values -> median ---
for col in numerical_cols:
    if df[col].isnull().sum() > 0:
        median_val = df[col].median()
        df[col] = df[col].fillna(median_val)
        print(f"Filled missing values in '{col}' with median = {median_val}")

# --- 3.6 Handle missing categorical values -> mode ---
for col in categorical_cols:
    if df[col].isnull().sum() > 0:
        mode_val = df[col].mode()[0]
        df[col] = df[col].fillna(mode_val)
        print(f"Filled missing values in '{col}' with mode = '{mode_val}'")

print(f"\nRemaining missing values after cleaning: {df.isnull().sum().sum()}")

# --- 3.7 Detect obviously invalid values ---
invalid_tenure = (df["tenure"] < 0).sum()
invalid_charges = (df["MonthlyCharges"] <= 0).sum()
print(f"Rows with negative tenure: {invalid_tenure}")
print(f"Rows with non-positive MonthlyCharges: {invalid_charges}")
df = df[(df["tenure"] >= 0) & (df["MonthlyCharges"] > 0)].reset_index(drop=True)

print(f"\nFinal cleaned dataset shape: {df.shape}")


# ==================================================================
# 4. EXPLORATORY DATA ANALYSIS
# ==================================================================
section("4. EXPLORATORY DATA ANALYSIS")

print("\nChurn rate by Contract type:")
print(df.groupby("Contract")["Churn"].apply(lambda s: (s == "Yes").mean().round(3)))

print("\nChurn rate by Internet Service:")
print(df.groupby("InternetService")["Churn"].apply(lambda s: (s == "Yes").mean().round(3)))

print(f"\nAverage tenure - Churned customers: {df.loc[df['Churn']=='Yes','tenure'].mean():.1f} months")
print(f"Average tenure - Retained customers: {df.loc[df['Churn']=='No','tenure'].mean():.1f} months")

# --- Churn factor visualizations ---
fig, axes = plt.subplots(2, 2, figsize=(13, 10))

sns.countplot(data=df, x="Contract", hue="Churn", ax=axes[0, 0], palette="Set2")
axes[0, 0].set_title("Churn Count by Contract Type")
axes[0, 0].set_xlabel("Contract Type")
axes[0, 0].set_ylabel("Number of Customers")

sns.histplot(data=df, x="tenure", hue="Churn", kde=True, ax=axes[0, 1],
             palette="Set1", element="step")
axes[0, 1].set_title("Tenure Distribution by Churn Status")
axes[0, 1].set_xlabel("Tenure (months)")
axes[0, 1].set_ylabel("Number of Customers")

sns.boxplot(data=df, x="Churn", y="MonthlyCharges", ax=axes[1, 0], palette="Set3")
axes[1, 0].set_title("Monthly Charges by Churn Status")
axes[1, 0].set_xlabel("Churn")
axes[1, 0].set_ylabel("Monthly Charges")

sns.countplot(data=df, x="InternetService", hue="Churn", ax=axes[1, 1], palette="Set2")
axes[1, 1].set_title("Churn Count by Internet Service")
axes[1, 1].set_xlabel("Internet Service")
axes[1, 1].set_ylabel("Number of Customers")

plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/churn_factors.png", dpi=150)
plt.close()
print(f"\nSaved: {OUTPUT_DIR}/churn_factors.png")

# --- Correlation heatmap (numerical features + binary target) ---
df_corr = df.copy()
df_corr["Churn_binary"] = (df_corr["Churn"] == "Yes").astype(int)
corr_df = df_corr[numerical_cols + ["Churn_binary"]].corr()

plt.figure(figsize=(7, 5.5))
sns.heatmap(corr_df, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5,
            cbar_kws={"label": "Correlation coefficient"})
plt.title("Correlation Heatmap (Numerical Features vs Churn)")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/correlation_heatmap.png", dpi=150)
plt.close()
print(f"Saved: {OUTPUT_DIR}/correlation_heatmap.png")


# ==================================================================
# 5. FEATURE SELECTION
# ==================================================================
section("5. FEATURE SELECTION")
feature_cols = numerical_cols + categorical_cols
print(f"Selected input features (before encoding): {feature_cols}")
print(f"Target variable: {target_col} (binary: Yes/No)")


# ==================================================================
# 6. DATA PREPROCESSING (encoding)
# ==================================================================
section("6. DATA PREPROCESSING - ENCODING")

# Encode target: Yes -> 1, No -> 0
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

# One-hot encode categorical features. drop_first=True avoids the dummy
# variable trap / redundant, leakage-prone columns.
df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
print(f"Shape before encoding: {df.shape}")
print(f"Shape after encoding: {df_encoded.shape}")

X = df_encoded.drop(columns=[target_col])
y = df_encoded[target_col]

print(f"\nFinal X shape: {X.shape}")
print(f"Final y shape: {y.shape}")
print(f"Class balance in y: {y.value_counts(normalize=True).round(3).to_dict()}")


# ==================================================================
# 7. TRAIN-TEST SPLIT
# ==================================================================
section("7. TRAIN-TEST SPLIT")

# Stratified split keeps the churn ratio consistent between train/test,
# important since churn is an imbalanced class.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
)
print(f"Training set size: {X_train.shape[0]} rows")
print(f"Testing set size:  {X_test.shape[0]} rows")
print(f"Train churn rate: {y_train.mean():.3f}  |  Test churn rate: {y_test.mean():.3f}")

# Scale features for Logistic Regression (helps convergence & coefficient comparability)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)


# ==================================================================
# 8. MODEL TRAINING - THREE MODELS
# ==================================================================
section("8. MODEL TRAINING")

models = {}

print("Training Logistic Regression...")
log_reg = LogisticRegression(max_iter=2000, random_state=RANDOM_STATE)
log_reg.fit(X_train_scaled, y_train)
models["Logistic Regression"] = ("scaled", log_reg)

print("Training Random Forest...")
rf = RandomForestClassifier(n_estimators=300, max_depth=8, random_state=RANDOM_STATE,
                             class_weight="balanced")
rf.fit(X_train, y_train)
models["Random Forest"] = ("raw", rf)

if XGBOOST_AVAILABLE:
    print("Training XGBoost...")
    xgb = XGBClassifier(
        n_estimators=300, max_depth=4, learning_rate=0.08,
        subsample=0.9, colsample_bytree=0.9, eval_metric="logloss",
        random_state=RANDOM_STATE
    )
    xgb.fit(X_train, y_train)
    models["XGBoost"] = ("raw", xgb)
else:
    print("XGBoost not available in this environment - skipping. "
          "Install with `pip install xgboost` to include it.")

print(f"\nModels trained: {list(models.keys())}")


# ==================================================================
# 9. PREDICTIONS + EVALUATION FOR EACH MODEL
# ==================================================================
section("9. PREDICTIONS & EVALUATION")

results = []
roc_data = {}
predictions_store = {}

for name, (mode, model) in models.items():
    X_eval = X_test_scaled if mode == "scaled" else X_test
    y_pred = model.predict(X_eval)
    y_proba = model.predict_proba(X_eval)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)

    results.append({"Model": name, "Accuracy": acc, "Precision": prec,
                     "Recall": rec, "F1-Score": f1, "ROC-AUC": auc})

    fpr, tpr, _ = roc_curve(y_test, y_proba)
    roc_data[name] = (fpr, tpr, auc)
    predictions_store[name] = (y_pred, y_proba)

    print(f"\n--- {name} ---")
    print(f"Accuracy:  {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall:    {rec:.4f}")
    print(f"F1-Score:  {f1:.4f}")
    print(f"ROC-AUC:   {auc:.4f}")
    print("\nClassification report:")
    print(classification_report(y_test, y_pred, target_names=["No Churn", "Churn"]))

    # Confusion matrix plot
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5.5, 4.8))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["No Churn", "Churn"], yticklabels=["No Churn", "Churn"])
    plt.title(f"Confusion Matrix - {name}")
    plt.xlabel("Predicted Label")
    plt.ylabel("Actual Label")
    plt.tight_layout()
    fname = name.lower().replace(" ", "_")
    plt.savefig(f"{OUTPUT_DIR}/confusion_matrix_{fname}.png", dpi=150)
    plt.close()
    print(f"Saved: {OUTPUT_DIR}/confusion_matrix_{fname}.png")

results_df = pd.DataFrame(results).sort_values("ROC-AUC", ascending=False).reset_index(drop=True)
print("\n\nModel comparison (sorted by ROC-AUC):")
print(results_df.to_string(index=False))
results_df.to_csv(f"{OUTPUT_DIR}/model_comparison.csv", index=False)
print(f"\nSaved: {OUTPUT_DIR}/model_comparison.csv")

best_model_name = results_df.iloc[0]["Model"]
print(f"\nBest performing model (by ROC-AUC): {best_model_name}")


# ==================================================================
# 10. ROC CURVE COMPARISON
# ==================================================================
section("10. ROC CURVE VISUALIZATION")

plt.figure(figsize=(7, 6))
colors = ["#2E86AB", "#A23B72", "#F18F01"]
for (name, (fpr, tpr, auc)), color in zip(roc_data.items(), colors):
    plt.plot(fpr, tpr, label=f"{name} (AUC = {auc:.3f})", color=color, linewidth=2)
plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random guess (AUC = 0.5)")
plt.title("ROC Curve Comparison - All Models")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.legend(loc="lower right")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/roc_curve_comparison.png", dpi=150)
plt.close()
print(f"Saved: {OUTPUT_DIR}/roc_curve_comparison.png")


# ==================================================================
# 11. FEATURE IMPORTANCE / MODEL INTERPRETATION
# ==================================================================
section("11. FEATURE IMPORTANCE (Random Forest)")

importances = pd.DataFrame({
    "Feature": X.columns,
    "Importance": rf.feature_importances_
}).sort_values("Importance", ascending=False).reset_index(drop=True)

print(importances.head(15).to_string(index=False))
importances.to_csv(f"{OUTPUT_DIR}/feature_importance.csv", index=False)

top15 = importances.head(15)
plt.figure(figsize=(9, 7))
sns.barplot(data=top15, y="Feature", x="Importance", palette="viridis")
plt.title("Top 15 Feature Importances (Random Forest)", fontsize=14)
plt.xlabel("Importance")
plt.ylabel("Feature")
plt.tight_layout()
plt.savefig(f"{OUTPUT_DIR}/feature_importance.png", dpi=150)
plt.close()
print(f"\nSaved: {OUTPUT_DIR}/feature_importance.png")

print("\nLogistic Regression coefficients (direction of effect):")
coef_df = pd.DataFrame({
    "Feature": X.columns,
    "Coefficient": log_reg.coef_[0]
}).sort_values("Coefficient", ascending=False).reset_index(drop=True)

def interpret(row):
    direction = "increases" if row["Coefficient"] > 0 else "decreases"
    return f"{direction} churn likelihood"

coef_df["Effect"] = coef_df.apply(interpret, axis=1)
print(coef_df.to_string(index=False))
coef_df.to_csv(f"{OUTPUT_DIR}/logreg_coefficients.csv", index=False)
print(f"\nSaved: {OUTPUT_DIR}/logreg_coefficients.csv")

print("\nTop churn-INCREASING factors (Logistic Regression):")
print(coef_df.head(5)[["Feature", "Coefficient"]].to_string(index=False))
print("\nTop churn-DECREASING factors (Logistic Regression):")
print(coef_df.tail(5)[["Feature", "Coefficient"]].to_string(index=False))


# ==================================================================
# 12. CROSS-VALIDATION (robustness check on best model)
# ==================================================================
section("12. CROSS-VALIDATION (Robustness Check)")

best_mode, best_model_obj = models[best_model_name]
X_cv = X_train_scaled if best_mode == "scaled" else X_train
cv_scores = cross_val_score(best_model_obj, X_cv, y_train, cv=5, scoring="roc_auc")
print(f"5-Fold CV ROC-AUC scores for {best_model_name}: {np.round(cv_scores, 4)}")
print(f"Mean CV ROC-AUC: {cv_scores.mean():.4f}  (Std: {cv_scores.std():.4f})")


# ==================================================================
# 13. SAVE PREDICTIONS
# ==================================================================
section("13. SAVE PREDICTIONS")

y_pred_best, y_proba_best = predictions_store[best_model_name]
predictions_df = X_test.copy()
predictions_df["Actual_Churn"] = y_test.values
predictions_df["Predicted_Churn"] = y_pred_best
predictions_df["Churn_Probability"] = y_proba_best.round(4)
predictions_df["Model_Used"] = best_model_name
predictions_df.to_csv("predictions.csv", index=False)
print("Saved: predictions.csv (in project root)")


# ==================================================================
# 14. CONCLUSION
# ==================================================================
section("14. CONCLUSION")
best_row = results_df.iloc[0]
print(f"""
Three models were trained and compared: Logistic Regression, Random Forest,
and XGBoost. The best performing model by ROC-AUC was **{best_model_name}**
with Accuracy={best_row['Accuracy']:.3f}, Recall={best_row['Recall']:.3f},
F1={best_row['F1-Score']:.3f}, ROC-AUC={best_row['ROC-AUC']:.3f}.

For churn prediction, RECALL on the "Churn" class is often the most
business-critical metric: missing a customer who is about to leave
(a false negative) is usually more costly than a false alarm, since
retention teams can act on flagged customers.

Cross-validation (mean ROC-AUC = {cv_scores.mean():.3f}) confirms the best
model's performance is stable across different data splits.

Key churn drivers identified: Month-to-month contracts, higher monthly
charges, fiber-optic internet without tech support/online security, and
shorter tenure are all associated with higher churn risk - consistent
with common telecom-industry findings.

Limitations: This is a snapshot model trained on a single point-in-time
dataset; it does not capture changing customer behavior over time, and
class imbalance means rarer churn cases are inherently harder to predict
perfectly. In production, this would need periodic retraining, and
correlation-based feature insights should not be read as guaranteed
causal drivers of churn.
""")

print("PROJECT COMPLETE - all outputs saved to the outputs/ folder.")
