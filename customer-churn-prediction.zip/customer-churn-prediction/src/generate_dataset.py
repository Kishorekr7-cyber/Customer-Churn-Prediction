"""
generate_dataset.py
--------------------
Generates a realistic, synthetic customer-churn dataset for the Customer
Churn Prediction academic project.

Why a synthetic dataset?
No dataset file was supplied with the task, and this environment has no
internet access to Kaggle/UCI. So instead of pretending a specific external
CSV exists, we programmatically generate a dataset that:
  - Uses the exact same column structure as the well-known public
    "Telco Customer Churn" dataset style (demographics, account info,
    services subscribed, monthly/total charges, churn label).
  - Encodes REAL, sensible relationships between features and churn
    (month-to-month contracts churn more, longer tenure churns less,
    no tech support churns more, higher monthly charges churn more,
    etc.) plus random noise, so the classification results are
    meaningful rather than arbitrary.
  - Deliberately includes some missing values, a few duplicate rows, and
    blank-string "TotalCharges" entries (a famous quirk of the real Telco
    dataset), so the "data cleaning" section has genuine work to do.

If you have a real dataset (e.g. Kaggle's "Telco-Customer-Churn.csv"),
simply replace data/customer_churn.csv with it (keep similar column
names) or adjust the column list in src/train_model.py.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 2000

customer_id = [f"CUST-{10000 + i}" for i in range(N)]

gender = np.random.choice(["Male", "Female"], N)
senior_citizen = np.random.choice([0, 1], N, p=[0.84, 0.16])
partner = np.random.choice(["Yes", "No"], N, p=[0.48, 0.52])
dependents = np.random.choice(["Yes", "No"], N, p=[0.30, 0.70])

tenure = np.random.gamma(shape=2.0, scale=15, size=N).clip(0, 72).round(0).astype(int)

phone_service = np.random.choice(["Yes", "No"], N, p=[0.90, 0.10])
multiple_lines = np.where(
    phone_service == "No", "No phone service",
    np.random.choice(["Yes", "No"], N, p=[0.42, 0.58])
)

internet_service = np.random.choice(["DSL", "Fiber optic", "No"], N, p=[0.35, 0.44, 0.21])

def dependent_service(base_choice_probs):
    out = []
    for isv in internet_service:
        if isv == "No":
            out.append("No internet service")
        else:
            out.append(np.random.choice(["Yes", "No"], p=base_choice_probs))
    return np.array(out)

online_security = dependent_service([0.35, 0.65])
online_backup = dependent_service([0.40, 0.60])
device_protection = dependent_service([0.40, 0.60])
tech_support = dependent_service([0.35, 0.65])
streaming_tv = dependent_service([0.45, 0.55])
streaming_movies = dependent_service([0.45, 0.55])

contract = np.random.choice(
    ["Month-to-month", "One year", "Two year"], N, p=[0.55, 0.24, 0.21]
)
paperless_billing = np.random.choice(["Yes", "No"], N, p=[0.59, 0.41])
payment_method = np.random.choice(
    ["Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"],
    N, p=[0.34, 0.23, 0.22, 0.21]
)

# ---- Monthly charges: base + add-ons ----
base_charge = np.where(internet_service == "Fiber optic", 55,
              np.where(internet_service == "DSL", 35, 20))
addon_charge = (
    (online_security == "Yes").astype(int) * 5
    + (online_backup == "Yes").astype(int) * 5
    + (device_protection == "Yes").astype(int) * 5
    + (tech_support == "Yes").astype(int) * 5
    + (streaming_tv == "Yes").astype(int) * 8
    + (streaming_movies == "Yes").astype(int) * 8
    + (phone_service == "Yes").astype(int) * 10
)
monthly_charges = (base_charge + addon_charge + np.random.normal(0, 5, N)).clip(18, 120).round(2)
total_charges = (monthly_charges * tenure + np.random.normal(0, 30, N)).clip(0, None).round(2)

# ---- Churn probability driven by realistic risk factors ----
risk = (
    -0.05 * tenure
    + np.where(contract == "Month-to-month", 1.8, np.where(contract == "One year", 0.4, -0.3))
    + 0.02 * monthly_charges
    + np.where(tech_support == "No", 0.6, 0)
    + np.where(online_security == "No", 0.4, 0)
    + np.where(internet_service == "Fiber optic", 0.5, 0)
    + np.where(partner == "No", 0.2, 0)
    + np.where(paperless_billing == "Yes", 0.2, 0)
    + np.where(payment_method == "Electronic check", 0.3, 0)
    + np.where(senior_citizen == 1, 0.25, 0)
    - 3.6  # baseline offset so overall churn rate lands near real-world (~25-30%)
)
churn_prob = 1 / (1 + np.exp(-risk))
churn = np.where(np.random.rand(N) < churn_prob, "Yes", "No")

df = pd.DataFrame({
    "customerID": customer_id,
    "gender": gender,
    "SeniorCitizen": senior_citizen,
    "Partner": partner,
    "Dependents": dependents,
    "tenure": tenure,
    "PhoneService": phone_service,
    "MultipleLines": multiple_lines,
    "InternetService": internet_service,
    "OnlineSecurity": online_security,
    "OnlineBackup": online_backup,
    "DeviceProtection": device_protection,
    "TechSupport": tech_support,
    "StreamingTV": streaming_tv,
    "StreamingMovies": streaming_movies,
    "Contract": contract,
    "PaperlessBilling": paperless_billing,
    "PaymentMethod": payment_method,
    "MonthlyCharges": monthly_charges,
    "TotalCharges": total_charges,
    "Churn": churn,
})

# ---- Introduce realistic messiness for the cleaning section ----
rng = np.random.RandomState(7)

# Famous Telco-dataset quirk: a few customers with 0 tenure have TotalCharges
# stored as a blank string instead of a number.
zero_tenure_idx = df.index[df["tenure"] == 0]
blank_idx = rng.choice(zero_tenure_idx, size=min(8, len(zero_tenure_idx)), replace=False) \
    if len(zero_tenure_idx) > 0 else []
df["TotalCharges"] = df["TotalCharges"].astype(object)
for i in blank_idx:
    df.loc[i, "TotalCharges"] = " "

# A few genuinely missing values elsewhere
for col, frac in [("MonthlyCharges", 0.01), ("tenure", 0.01), ("PaymentMethod", 0.01),
                   ("InternetService", 0.005)]:
    idx = rng.choice(df.index, size=int(frac * N), replace=False)
    df.loc[idx, col] = np.nan

# A handful of duplicate rows
dup_rows = df.sample(6, random_state=7)
df = pd.concat([df, dup_rows], ignore_index=True)

# Shuffle
df = df.sample(frac=1, random_state=7).reset_index(drop=True)

df.to_csv("/home/claude/customer-churn-prediction/data/customer_churn.csv", index=False)
print("Dataset generated:", df.shape)
print(df["Churn"].value_counts(normalize=True))
print(df.head())
